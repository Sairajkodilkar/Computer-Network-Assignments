#!/usr/bin/env python

from library import *
import struct
import random
import socket

serverAddress = 'localhost'
serverPort = 8080

if(len(sys.argv) < 2):
    print("Usage ./client.py <probablity>")
    sys.exit(0)

probablity = float(sys.argv[1])
rdt = RDT(1 - probablity)

rdt.connect((serverAddress, serverPort))

n = random.randint(1, 50)

data = struct.pack("!h", n) 
try:
    rdt.send(data)
except socket.timeout:
    print("Server may be offline")

randomList = []
sumOfNumbers = 0
for i in range(n):
    randomNumber = random.randint(1, 50)
    randomList.append(randomNumber)
sumOfNumbers = sum(randomList)

randomNumbers = struct.pack("!" + str(n) + "h", *randomList)
print("list of random numbers")
try:
    rdt.send(randomNumbers)
except socket.timeout:
    print("Server may be offline")
reply = rdt.recv(1024)
sumFromServer = struct.unpack("!h", reply)[0]

if(sumFromServer == sumOfNumbers):
    print("=========Sum is correct========")
else:
    print("=========Error in the sum======")

